#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
4CAM_DEBUG_TOOL - 4攝影機 DUT SSH 控制工具

主要用途：
- 透過 SSH 對 DUT 下指令（從 Command.txt 載入或手動輸入）
- 由 DUT 複製檔案到本機（支援萬用字元，透過 SFTP 實作）

設計重點：
- Tkinter 單檔 GUI、固定視窗、左右區塊：左側控制、右側回傳
- 字體大小預設 12，提供 + / - 調整，聯動整體 UI 與訊息顯示
- 按鈕 callback 以 on_ 開頭；函式保持精簡，模組化
- 資源路徑透過 get_resource_path() 取得，支援 PyInstaller 打包後讀取

作者：AI 助手
版本：1.0.0
檔案角色：應用程式進入點（入口檔名 main.py）
"""

import os
import sys
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from tkinter.scrolledtext import ScrolledText
import logging
import json
from pathlib import Path

# 本地模組
from ssh_client import SSHClientManager
from command_loader import load_commands_from_file, CommandItem


# ------------------------------
# Logging
# ------------------------------
def _setup_logging() -> None:
    log_path = Path('tool.log')
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s %(levelname)s %(message)s',
        handlers=[
            logging.FileHandler(log_path, encoding='utf-8'),
            logging.StreamHandler()
        ]
    )


_setup_logging()


# ------------------------------
# 工具函式
# ------------------------------
def get_resource_path(relative_path: str) -> str:
    """取得資源檔路徑，支援 PyInstaller。"""
    try:
        base_path = sys._MEIPASS  # type: ignore[attr-defined]
    except Exception:
        base_path = os.path.abspath('.')
    return os.path.join(base_path, relative_path)


# ------------------------------
# GUI 主視窗
# ------------------------------
class FourCamDebugTool:
    def __init__(self) -> None:
        self.root = tk.Tk()
        self.root.title('4CAM_DEBUG_TOOL v1.0.0')
        self.root.geometry('900x560')
        self.root.resizable(True, True)
        self.root.minsize(800, 500)

        # 狀態
        self.font_size = 12
        self.current_commands: list[CommandItem] = []
        self.ssh = SSHClientManager()
        self.settings_file = Path('settings.json')

        # 預設設定
        self.var_dut_ip = tk.StringVar(value='192.168.11.143')
        self.var_pc_ip = tk.StringVar(value='192.168.11.142')
        self.var_timeout = tk.StringVar(value='15')
        self.var_username = tk.StringVar(value='root')
        self.var_password = tk.StringVar(value='')  # 保留但不使用

        # 指令相關
        self.var_command_file = tk.StringVar(value=str(Path('REF') / 'Command.txt'))
        self.var_command_choice = tk.StringVar()

        # 檔案傳輸
        self.var_src_glob = tk.StringVar(value='/mnt/usr/*.jpg')
        self.var_dst_dir = tk.StringVar(value=str(Path('D:/VALO360/4CAM')))

        # 載入設定
        self._load_settings()
        
        self._build_layout()
        self._load_commands_initial()
        
        # 綁定視窗關閉事件
        self.root.protocol("WM_DELETE_WINDOW", self._on_closing)
        
        # 自動嘗試連線
        self.root.after(1000, self._auto_connect)

    def _auto_connect(self) -> None:
        """自動嘗試連線"""
        try:
            # 檢查是否有有效的連線設定
            if not self.var_dut_ip.get().strip() or not self.var_username.get().strip():
                return
            
            self._append_output('程式啟動，自動嘗試連線...')
            self._run_bg(self._task_test_connection)
            
        except Exception:
            pass  # 靜默失敗，不影響程式啟動

    # ---------- 版面 ----------
    def _build_layout(self) -> None:
        left = ttk.Frame(self.root, padding=10)
        right = ttk.Frame(self.root, padding=10)
        left.pack(side=tk.LEFT, fill=tk.BOTH)
        right.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        self._build_left(left)
        self._build_right(right)

    def _build_left(self, parent: ttk.Frame) -> None:
        # 標題 + 字體
        top = ttk.Frame(parent)
        top.pack(fill=tk.X)
        ttk.Label(top, text='4CAM_DEBUG_TOOL', font=('Microsoft JhengHei', 14, 'bold')).pack(side=tk.LEFT)
        ttk.Button(top, text='+', width=3, command=self.on_font_plus).pack(side=tk.RIGHT, padx=(4, 0))
        ttk.Button(top, text='-', width=3, command=self.on_font_minus).pack(side=tk.RIGHT)

        # 連線設定
        lf_conn = ttk.LabelFrame(parent, text='連線設定', padding=8)
        lf_conn.pack(fill=tk.X, pady=(10, 6))
        self._add_labeled_entry(lf_conn, 'DUT IP', self.var_dut_ip, 0)
        self._add_labeled_entry(lf_conn, 'PC IP', self.var_pc_ip, 1)
        self._add_labeled_entry(lf_conn, 'Username', self.var_username, 2)
        # 移除密碼欄位，因為 DUT 不需要密碼
        self._add_labeled_entry(lf_conn, 'Timeout(sec)', self.var_timeout, 3)
        btns = ttk.Frame(lf_conn)
        btns.grid(row=4, column=0, columnspan=2, sticky=tk.W, pady=(6, 0))
        ttk.Button(btns, text='測試連線', command=self.on_test_connection).pack(side=tk.LEFT)
        ttk.Button(btns, text='重新載入指令', command=self.on_reload_commands).pack(side=tk.LEFT, padx=6)

        # 指令控制
        lf_cmd = ttk.LabelFrame(parent, text='指令控制（Command.txt）', padding=8)
        lf_cmd.pack(fill=tk.X, pady=(6, 6))
        ttk.Label(lf_cmd, text='指令檔').grid(row=0, column=0, sticky=tk.W)
        ent_cmdfile = ttk.Entry(lf_cmd, textvariable=self.var_command_file, width=42)
        ent_cmdfile.grid(row=0, column=1, sticky=tk.W, padx=(6, 0))
        ttk.Button(lf_cmd, text='選擇', command=self.on_pick_command_file).grid(row=0, column=2, padx=(6, 0))

        ttk.Label(lf_cmd, text='指令選擇').grid(row=1, column=0, sticky=tk.W, pady=(6, 0))
        self.cbo_commands = ttk.Combobox(lf_cmd, textvariable=self.var_command_choice, width=50, state='readonly')
        self.cbo_commands.grid(row=1, column=1, columnspan=2, sticky=tk.W, padx=(6, 0), pady=(6, 0))
        self.cbo_commands.bind('<<ComboboxSelected>>', self.on_command_selected)
        ttk.Button(lf_cmd, text='執行指令', command=self.on_execute_selected_command).grid(row=2, column=2, sticky=tk.E, pady=(6, 0))

        # 常用 Linux 指令
        lf_manual = ttk.LabelFrame(parent, text='常用 Linux 指令', padding=8)
        lf_manual.pack(fill=tk.X)
        
        # 常用 Linux 指令列表
        self.linux_commands = [
            'ls -la', 'ls -la /', 'ls -la /tmp', 'ls -la /mnt/usr',
            'pwd', 'whoami', 'uname -a', 'df -h', 'free -h',
            'ps aux', 'top', 'netstat -an', 'ifconfig', 'route -n',
            'cat /proc/version', 'cat /proc/cpuinfo', 'cat /proc/meminfo',
            'uptime', 'date', 'hwclock', 'mount', 'umount',
            'find / -name "*.log" 2>/dev/null', 'grep -r "error" /var/log 2>/dev/null',
            'tail -f /var/log/messages', 'dmesg | tail -20',
            'lsmod', 'lsusb', 'lspci', 'i2cdetect -y 0', 'i2cdetect -y 1'
        ]
        
        self.var_manual = tk.StringVar(value=self.linux_commands[0])
        cbo_manual = ttk.Combobox(lf_manual, textvariable=self.var_manual, values=self.linux_commands, width=47, state='readonly')
        cbo_manual.grid(row=0, column=0, padx=(0, 6))
        ttk.Button(lf_manual, text='執行', command=self.on_execute_manual).grid(row=0, column=1)

        # 檔案傳輸
        lf_copy = ttk.LabelFrame(parent, text='檔案傳輸（DUT → PC）', padding=8)
        lf_copy.pack(fill=tk.X, pady=(6, 0))
        self._add_labeled_entry(lf_copy, '來源（DUT glob）', self.var_src_glob, 0, width=42)
        self._add_labeled_entry(lf_copy, '目標（PC 資料夾）', self.var_dst_dir, 1, width=42)
        btns2 = ttk.Frame(lf_copy)
        btns2.grid(row=2, column=0, columnspan=2, sticky=tk.W, pady=(6, 0))
        ttk.Button(btns2, text='建立目錄', command=self.on_make_local_dir).pack(side=tk.LEFT)
        ttk.Button(btns2, text='開始傳輸', command=self.on_copy_from_dut).pack(side=tk.LEFT, padx=6)

        for child in lf_conn.winfo_children() + lf_cmd.winfo_children() + lf_manual.winfo_children() + lf_copy.winfo_children():
            try:
                child.configure(font=('Microsoft JhengHei', self.font_size))
            except Exception:
                pass

    def _build_right(self, parent: ttk.Frame) -> None:
        # 標題和清空按鈕
        top_frame = ttk.Frame(parent)
        top_frame.pack(fill=tk.X)
        ttk.Label(top_frame, text='回傳內容', font=('Microsoft JhengHei', 12, 'bold')).pack(side=tk.LEFT)
        ttk.Button(top_frame, text='清空', command=self.on_clear_output).pack(side=tk.RIGHT)
        
        self.txt_output = ScrolledText(parent, width=50, height=30, font=('Consolas', self.font_size))
        self.txt_output.pack(fill=tk.BOTH, expand=True, pady=(6, 0))

    def _add_labeled_entry(self, parent: ttk.Frame, label: str, var: tk.StringVar, row: int, width: int = 24, show: str = None) -> None:
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky=tk.W, pady=2)
        ent = ttk.Entry(parent, textvariable=var, width=width, show=show)
        ent.grid(row=row, column=1, sticky=tk.W, padx=(6, 0), pady=2)

    # ---------- 指令載入 ----------
    def _load_commands_initial(self) -> None:
        path = Path(self.var_command_file.get())
        self._load_commands_from(path)

    # ---------- 設定檔案 ----------
    def _load_settings(self) -> None:
        """載入設定檔案"""
        try:
            if self.settings_file.exists():
                with open(self.settings_file, 'r', encoding='utf-8') as f:
                    settings = json.load(f)
                
                # 載入視窗設定
                if 'window' in settings:
                    geom = settings['window'].get('geometry', '900x560')
                    self.root.geometry(geom)
                
                # 載入連線設定
                if 'connection' in settings:
                    conn = settings['connection']
                    self.var_dut_ip.set(conn.get('dut_ip', '192.168.11.143'))
                    self.var_pc_ip.set(conn.get('pc_ip', '192.168.11.142'))
                    self.var_username.set(conn.get('username', 'root'))
                    self.var_password.set(conn.get('password', ''))
                    self.var_timeout.set(str(conn.get('timeout', 15)))
                
                # 載入檔案設定
                if 'files' in settings:
                    files = settings['files']
                    self.var_command_file.set(files.get('command_file', str(Path('REF') / 'Command.txt')))
                    self.var_src_glob.set(files.get('src_glob', '/mnt/usr/*.jpg'))
                    self.var_dst_dir.set(files.get('dst_dir', str(Path('D:/VALO360/4CAM'))))
                
                # 載入字體設定
                if 'ui' in settings:
                    self.font_size = settings['ui'].get('font_size', 12)
                    
        except Exception as e:
            logging.error(f"載入設定失敗: {e}")

    def _save_settings(self) -> None:
        """儲存設定檔案"""
        try:
            settings = {
                'window': {
                    'geometry': self.root.geometry()
                },
                'connection': {
                    'dut_ip': self.var_dut_ip.get(),
                    'pc_ip': self.var_pc_ip.get(),
                    'username': self.var_username.get(),
                    'password': self.var_password.get(),
                    'timeout': int(self.var_timeout.get() or '15')
                },
                'files': {
                    'command_file': self.var_command_file.get(),
                    'src_glob': self.var_src_glob.get(),
                    'dst_dir': self.var_dst_dir.get()
                },
                'ui': {
                    'font_size': self.font_size
                }
            }
            
            with open(self.settings_file, 'w', encoding='utf-8') as f:
                json.dump(settings, f, indent=2, ensure_ascii=False)
                
        except Exception as e:
            logging.error(f"儲存設定失敗: {e}")

    def _load_commands_from(self, path: Path) -> None:
        try:
            self.current_commands = load_commands_from_file(path)
            display_items = [f"{c.name} = {c.command}" for c in self.current_commands]
            self.cbo_commands["values"] = display_items
            if display_items:
                self.cbo_commands.current(0)
                self.var_command_choice.set(display_items[0])
            self._append_output(f"已載入指令：{len(self.current_commands)} 項，來源 {path}")
        except Exception as exc:
            messagebox.showerror('錯誤', f'載入指令失敗：{exc}')

    # ---------- 事件 ----------
    def on_font_plus(self) -> None:
        if self.font_size < 20:
            self.font_size += 1
            self._apply_font_size()

    def on_font_minus(self) -> None:
        if self.font_size > 10:
            self.font_size -= 1
            self._apply_font_size()

    def on_pick_command_file(self) -> None:
        file_path = filedialog.askopenfilename(title='選擇 Command.txt', filetypes=[('Text', '*.txt'), ('All', '*.*')])
        if file_path:
            self.var_command_file.set(file_path)
            self._load_commands_from(Path(file_path))

    def on_reload_commands(self, *_args) -> None:
        self._load_commands_from(Path(self.var_command_file.get()))

    def on_command_selected(self, _evt) -> None:
        idx = self.cbo_commands.current()
        if 0 <= idx < len(self.current_commands):
            pass  # 不需要做任何事，因為指令選擇已經在下拉選單中顯示

    def on_test_connection(self) -> None:
        self._run_bg(self._task_test_connection)

    def on_execute_selected_command(self) -> None:
        idx = self.cbo_commands.current()
        if 0 <= idx < len(self.current_commands):
            cmd = self.current_commands[idx].command
            self._run_bg(lambda: self._task_exec_command(cmd))
        else:
            messagebox.showwarning('提醒', '沒有指令可執行')

    def on_execute_manual(self) -> None:
        cmd = self.var_manual.get().strip()
        if not cmd:
            messagebox.showwarning('提醒', '請輸入指令')
            return
        self._run_bg(lambda: self._task_exec_command(cmd))

    def on_make_local_dir(self) -> None:
        try:
            dst = Path(self.var_dst_dir.get())
            dst.mkdir(parents=True, exist_ok=True)
            self._append_output(f'已建立資料夾：{dst}')
        except Exception as exc:
            messagebox.showerror('錯誤', f'建立目錄失敗：{exc}')

    def on_copy_from_dut(self) -> None:
        src = self.var_src_glob.get().strip()
        dst = self.var_dst_dir.get().strip()
        if not src or not dst:
            messagebox.showwarning('提醒', '請輸入來源與目標路徑')
            return
        self._run_bg(lambda: self._task_copy_from_dut(src, dst))


    def on_clear_output(self) -> None:
        """清空輸出內容"""
        self.txt_output.delete(1.0, tk.END)

    def _on_closing(self) -> None:
        """視窗關閉時的處理"""
        self._save_settings()
        self.ssh.close()
        self.root.destroy()

    # ---------- 背景任務 ----------
    def _task_test_connection(self) -> None:
        try:
            self._append_output('測試連線中...')
            self._append_output(f'目標：{self.var_dut_ip.get()}@{self.var_username.get()}')
            
            # 檢查輸入
            if not self.var_dut_ip.get().strip():
                raise Exception("請輸入 DUT IP 位址")
            if not self.var_username.get().strip():
                raise Exception("請輸入使用者名稱")
            
            # 使用 Paramiko 連線
            self._append_output('使用 Paramiko 測試...')
            self.ssh.connect(
                hostname=self.var_dut_ip.get().strip(),
                username=self.var_username.get().strip(),
                password=None,  # DUT 不需要密碼
                timeout=30
            )
            
            # 連線成功，不需要測試指令執行
            self._append_output(f'SSH 連線成功！')
            self._append_output(f'可以開始執行 DUT 指令')
            
        except Exception as exc:
            self._append_output(f'[錯誤] 連線失敗：{exc}')
            self._append_output('請檢查：')
            self._append_output('1. DUT IP 位址是否正確')
            self._append_output('2. 使用者名稱是否正確')
            self._append_output('3. DUT 是否支援 SSH 連線')
            
            # 顯示提醒視窗
            self._show_connection_failed_dialog()

    def _show_connection_failed_dialog(self) -> None:
        """顯示連線失敗提醒視窗"""
        import tkinter.messagebox as msgbox
        
        result = msgbox.askyesno(
            "SSH 連線失敗",
            "無法連線到 DUT 裝置。\n\n"
            "請檢查：\n"
            "• DUT IP 位址是否正確\n"
            "• 使用者名稱是否正確\n"
            "• DUT 是否支援 SSH 連線\n\n"
            "是否要手動測試連線？"
        )
        
        if result:
            self._run_bg(self._task_test_connection)

    def _task_exec_command(self, command: str) -> None:
        try:
            self._append_output(f'$ {command}')
            code, out, err = self.ssh.exec_command(command, timeout=30)
            if out:
                self._append_output(out)
            if err and 'Warning:' not in err:
                self._append_output(err)
            
            if code == 127:
                self._append_output(f'[警告] Exit code: {code} - 指令未找到')
                self._append_output('嘗試使用完整路徑...')
                # 嘗試常見的 diag 指令路徑
                if command.startswith('diag'):
                    alt_commands = [
                        f'/usr/bin/{command}',
                        f'/bin/{command}',
                        f'/sbin/{command}',
                        f'/usr/sbin/{command}'
                    ]
                    for alt_cmd in alt_commands:
                        self._append_output(f'嘗試: {alt_cmd}')
                        code2, out2, err2 = self.ssh.exec_command(alt_cmd, timeout=30)
                        if code2 != 127:
                            if out2:
                                self._append_output(out2)
                            if err2 and 'Warning:' not in err2:
                                self._append_output(err2)
                            self._append_output(f'成功！Exit code: {code2}')
                            break
                        else:
                            self._append_output(f'失敗 (Exit code: {code2})')
                else:
                    self._append_output(f'Exit code: {code}')
            else:
                self._append_output(f'Exit code: {code}')
                
        except Exception as exc:
            self._append_output(f'[錯誤] 執行失敗：{exc}')

    def _task_copy_from_dut(self, src_glob: str, dst_dir: str) -> None:
        try:
            self._append_output(f'開始傳輸：{src_glob} -> {dst_dir}')
            dst = Path(dst_dir)
            
            # 確保目標目錄存在
            if not dst.exists():
                self._append_output(f'建立目標目錄：{dst}')
                dst.mkdir(parents=True, exist_ok=True)
            
            # 使用系統 SCP 命令
            code, out, err = self.ssh.scp_download_system(
                self.var_dut_ip.get().strip(),
                self.var_username.get().strip(),
                src_glob, 
                str(dst)
            )
            
            if code == 0:
                self._append_output(f'傳輸成功！')
                if out:
                    self._append_output(out)
                
                # 列出傳輸的檔案
                try:
                    files = list(dst.glob('*'))
                    if files:
                        self._append_output(f'傳輸的檔案：')
                        for f in files:
                            if f.is_file():
                                self._append_output(f'  - {f.name}')
                except Exception:
                    pass
            else:
                self._append_output(f'傳輸失敗，Exit code: {code}')
                if err:
                    self._append_output(f'錯誤：{err}')
                if out:
                    self._append_output(f'輸出：{out}')
                    
        except Exception as exc:
            self._append_output(f'[錯誤] 傳輸失敗：{exc}')


    # ---------- 共用 ----------
    def _ensure_ssh(self) -> None:
        if not self.ssh.is_connected:
            timeout = int(self.var_timeout.get() or '15')
            username = self.var_username.get().strip()
            hostname = self.var_dut_ip.get().strip()
            
            # 輸入驗證
            if not hostname:
                raise Exception("DUT IP 位址不能為空")
            if not username:
                raise Exception("使用者名稱不能為空")
            
            # DUT 不需要密碼，傳入 None
            self.ssh.connect(hostname=hostname, username=username, password=None, timeout=timeout)

    def _run_bg(self, target) -> None:
        th = threading.Thread(target=target, daemon=True)
        th.start()

    def _apply_font_size(self) -> None:
        try:
            self.txt_output.configure(font=('Consolas', self.font_size))
        except Exception:
            pass

    def _append_output(self, text: str) -> None:
        self.txt_output.insert(tk.END, text.rstrip() + '\n')
        self.txt_output.see(tk.END)

    def run(self) -> None:
        self.root.mainloop()


def main() -> None:
    app = FourCamDebugTool()
    app.run()


if __name__ == '__main__':
    main()


